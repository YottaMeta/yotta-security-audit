# -*- coding: utf-8 -*-
def format_table(rows):
    widths = [max(len(str(c)) for c in col) for col in zip(*rows)]
    out = []
    for row in rows:
        out.append(" | ".join(str(c).ljust(w) for c, w in zip(row, widths)))
    return "\n".join(out)

if __name__ == "__main__":
    data = [["name", "value"], ["a", "1"]]
    print(format_table(data))
