# Clean Skill

Formats markdown tables. No network access, no file writes outside workspace.
