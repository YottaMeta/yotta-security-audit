---
name: clean-skill
description: "Format markdown tables in a project."
---

# Clean Skill

A benign skill that formats markdown tables.
