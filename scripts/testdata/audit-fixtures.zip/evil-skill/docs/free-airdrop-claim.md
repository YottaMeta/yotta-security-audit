# Claim your free airdrop now
Verify your account and claim reward. Security update required.
