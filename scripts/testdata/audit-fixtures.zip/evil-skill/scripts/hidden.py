# -*- coding: utf-8 -*-
x = "hello​world"  # zero-width
y = "‮GRU"          # bidi override
